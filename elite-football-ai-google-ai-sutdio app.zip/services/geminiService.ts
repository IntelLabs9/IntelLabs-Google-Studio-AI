
import { GoogleGenAI } from "@google/genai";
import { Match, PredictionResult } from '../types';

const getAiClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
};

export const generateMatchPrediction = async (match: Match): Promise<PredictionResult> => {
  const ai = getAiClient();
  
  // Determine Match State
  const isLive = match.isLive;
  const minute = parseInt(match.time.replace("'", "")) || 0;
  const isLateGame = isLive && minute > 65;
  const winningTeam = match.momentum > 0 ? 'Home' : 'Away';
  const leaderName = match.momentum > 0 ? match.homeTeam.name : match.awayTeam.name;

  // Fallback for demo if no API Key
  if (!ai) {
    await new Promise(resolve => setTimeout(resolve, 5500)); // Extended time for advanced animation
    
    if (isLive) {
        if (isLateGame) {
           return {
             aggressive: `Over 1.5 Goals (Total)`,
             conservative: `Over 0.5 Goals (Rest of Match)`,
             reasoning: `• High Pressure: ${leaderName} creates 3+ chances per minute since 70'.\n• Fatigue: Defensive gaps widening; xG suggests imminent goal.\n• Momentum: Sustained attack in final third (+${Math.abs(match.momentum)} index).`,
             type: 'LIVE_INSIGHT'
           };
        }

        const reasoning = `• Momentum Shift: ${leaderName} dominating dangerous attacks (xG 1.42 vs 0.3).\n• Tactical Mismatch: Overload on the right flank exploiting the fullback's yellow card.\n• Form: ${match.homeTeam.name} scores 60% of goals in this phase.`;

        return {
            aggressive: `${leaderName} Win & BTTS`,
            conservative: `${leaderName} Win (Draw No Bet)`,
            reasoning: reasoning,
            type: 'LIVE_INSIGHT'
        };
    } else {
        // Enhanced Pre-Match Fallback
        return {
            aggressive: `${match.homeTeam.name} Win & Over 2.5 Goals`,
            conservative: `${match.homeTeam.name} Win or Draw`,
            reasoning: `• Key Injury: ${match.awayTeam.name}'s star striker is ruled out, reducing offensive output by 40%.\n• Form: ${match.homeTeam.name} are unbeaten at home in 8 matches.\n• Standings: Critical match for ${match.homeTeam.name} to secure top 4 spot.`,
            type: 'PRE_MATCH'
        };
    }
  }

  try {
    let promptContext = "";
    let specificInstructions = "";

    if (isLive) {
      promptContext = `
        STATUS: LIVE MATCH (${match.time})
        Score: ${match.homeTeam.name} ${match.homeTeam.score} - ${match.awayTeam.score} ${match.awayTeam.name}
        Momentum Index: ${match.momentum} (Scale: -100 Away to +100 Home)
        Stats:
        - Possession: Home ${match.stats.homePossession}% vs Away ${match.stats.awayPossession}%
        - Shots (On Target): Home ${match.stats.homeShots}(${match.stats.homeOnTarget}) - Away ${match.stats.awayShots}(${match.stats.awayOnTarget})
        - Corners: Home ${match.stats.homeCorners} - Away ${match.stats.awayCorners}
        - Cards: Home (Y:${match.stats.homeYellowCards}/R:${match.stats.homeRedCards}) - Away (Y:${match.stats.awayYellowCards}/R:${match.stats.awayRedCards})
      `;
      
      if (isLateGame) {
        specificInstructions = `
        TASK: Generate LATE GAME LIVE predictions (Post-65th Minute).
        
        CRITERIA:
        - PRIORITIZE Goal Markets based on desperation/fatigue.
        
        AGGRESSIVE Prediction (High Yield):
        - "Over 1.5 Goals" (Total) 
        - "Next Goal: [Team]" (if momentum is > 60)
        
        CONSERVATIVE Prediction (High Safety):
        - "Over 0.5 Goals" (Rest of Match) -> This is the primary recommendation for late games with high momentum.
        - Handicap (+)
        
        MANDATORY REASONING:
        - Cite momentum index.
        - Mention defensive fatigue vs attacking urgency.
        `;
      } else {
        specificInstructions = `
        TASK: Generate LIVE predictions based on momentum.
        
        CRITERIA FOR "AGGRESSIVE":
        - Match Winner
        - Tie Result
        - +1.5 Goals in Second Half
        - +2.5 Goals Total (Live)
        
        CRITERIA FOR "CONSERVATIVE":
        - +0.5 Goals in Second Half
        - Handicap +
        - +1.5 Goals Total (if Early)
        
        MANDATORY REASONING:
        - Must cite momentum shifts.
        - Must infer fatigue or tactical gaps based on stats.
        `;
      }

    } else {
      // Pre-Match Logic
      promptContext = `
        STATUS: PRE-MATCH
        Home Form: ${match.homeTeam.form.map(f => f.result).join('-')}
        Away Form: ${match.awayTeam.form.map(f => f.result).join('-')}
      `;
      specificInstructions = `
        TASK: Generate PRE-MATCH predictions.
        
        CRITERIA FOR "AGGRESSIVE" (High Risk/Reward):
        - Both Teams to Score (BTTS) AND Winner
        - Winner AND +2.5 Goals
        - Winner AND Under 2.5 Goals
        
        CRITERIA FOR "CONSERVATIVE" (Lower Risk):
        - Both Teams to Score AND +2.5 Goals (if high converting)
        - Match Winner
        - +1.5 Goals Total
        
        MANDATORY REASONING:
        1. Key Player Form / Major Injuries (Fabricate realistic insights based on team stature if real data unavailable).
        2. Current Team Form.
        3. League Standings Context / Motivation.
      `;
    }

    const prompt = `
      You are an Elite Football Betting Analyst AI.
      
      Match: ${match.homeTeam.name} vs ${match.awayTeam.name}
      League: ${match.league}
      
      ${promptContext}
      
      ${specificInstructions}
      
      Return ONLY a JSON object with this schema:
      {
        "aggressive": "string (e.g., 'Home Win & BTTS')",
        "conservative": "string (e.g., 'Over 1.5 Goals')",
        "reasoning": "string (A list of 3 distinct bullet points starting with '•', separated by newlines. Max 25 words per point. Must include Injury/Player insights)",
        "type": "${isLive ? 'LIVE_INSIGHT' : 'PRE_MATCH'}"
      }
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response text");
    
    return JSON.parse(text) as PredictionResult;

  } catch (error) {
    console.error("Gemini API Error:", error);
    return {
      aggressive: "Analysis Unavailable",
      conservative: "Try Again",
      reasoning: "• Live data feed connection interrupted.\n• Neural engine recalibrating.\n• Please retry in a few seconds.",
      type: 'LIVE_INSIGHT'
    };
  }
};
