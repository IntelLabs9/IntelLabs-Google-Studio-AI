
import React from 'react';
import { Home, Star, User } from 'lucide-react';

interface BottomNavProps {
  activeTab: 'matches' | 'favorites' | 'profile';
  setActiveTab: (tab: 'matches' | 'favorites' | 'profile') => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  const navItems = [
    { id: 'matches', icon: Home, label: 'Matches' },
    { id: 'favorites', icon: Star, label: 'Favorites' },
    { id: 'profile', icon: User, label: 'Profile' },
  ] as const;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[60] pb-safe mx-auto max-w-md pointer-events-none">
      {/* Blur Background Container - Pointer Events Auto for interaction */}
      <div className="absolute inset-0 bg-[#0A0E27]/90 backdrop-blur-xl border-t border-white/10 pointer-events-auto" />
      
      <div className="relative flex justify-around items-center p-3 pb-5 pointer-events-auto">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className="flex flex-col items-center justify-center gap-1.5 min-w-[64px] group"
            >
              <div className={`
                p-1.5 rounded-xl transition-all duration-300 relative
                ${isActive ? 'bg-indigo-500/20 text-indigo-400' : 'text-white/40 group-hover:text-white/60'}
              `}>
                {isActive && (
                  <div className="absolute inset-0 bg-indigo-500/20 blur-md rounded-xl" />
                )}
                <item.icon className="w-5 h-5 relative z-10" strokeWidth={isActive ? 2.5 : 2} />
              </div>
              <span className={`text-[9px] font-tech uppercase tracking-wider transition-colors ${isActive ? 'text-white font-bold' : 'text-white/30'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
