
import React, { useMemo, useState } from 'react';
import { MatchEvent } from '../types';
import { Circle, X } from 'lucide-react';

interface NebulaTrackerProps {
  history: number[];
  currentMomentum: number;
  events: MatchEvent[];
  matchDuration: number;
  homeTeamId: string;
  awayTeamId: string;
  homeTeamLogo: string;
  awayTeamLogo: string;
}

// Custom Soccer Ball SVG
const SoccerBall = () => (
  <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 shadow-sm rounded-full overflow-visible">
    <circle cx="12" cy="12" r="11" fill="white" stroke="#111" strokeWidth="1.5"/>
    <path d="M12 2.5L14.5 6.5H19.5L16.5 10.5L18.5 15.5L13.5 14L10.5 18.5L7.5 14L2.5 15.5L4.5 10.5L1.5 6.5H6.5L9 2.5H15Z" fill="#111" opacity="0.8"/>
    <path d="M12 7L14.35 9.85L18 9.1L16.2 12.2L18 15.3L14.35 14.55L12 17.4L9.65 14.55L6 15.3L7.8 12.2L6 9.1L9.65 9.85L12 7Z" fill="#111"/>
  </svg>
);

export const NebulaTracker: React.FC<NebulaTrackerProps> = ({ 
  history, 
  currentMomentum, 
  events, 
  matchDuration,
  homeTeamId,
  awayTeamId,
  homeTeamLogo,
  awayTeamLogo
}) => {
  const [activeEventId, setActiveEventId] = useState<string | null>(null);

  // Data setup
  const data = history.length > 0 ? history : [0, 0];
  
  // Dimensions
  const height = 60;
  const width = 100; 
  const zeroY = height / 2;
  const maxTime = Math.max(90, matchDuration);
  
  // Determine current progress for the "Live" beacon
  const currentProgressPercent = (matchDuration / maxTime) * 100;

  // Generate SVG Path
  const pathD = useMemo(() => {
    if (data.length < 2) return `M 0 ${zeroY} L ${width} ${zeroY}`;
    const activeWidth = (matchDuration / maxTime) * width;
    const stepX = activeWidth / (data.length - 1);
    
    let path = `M 0 ${zeroY} `; 
    data.forEach((value, index) => {
      const x = index * stepX;
      // > 0 is Home (Top), < 0 is Away (Bottom)
      const y = zeroY - (value / 100) * (height / 2 * 0.9);
      path += `L ${x} ${y} `;
    });
    path += `L ${activeWidth} ${zeroY} Z`;
    return path;
  }, [data, matchDuration, maxTime, zeroY]);

  return (
    <div 
      className="w-full py-2 relative select-none flex items-center gap-3"
      onClick={() => setActiveEventId(null)}
    >
      {/* LEFT COLUMN: Logos (Reverted to w-6 h-6 for 24px) */}
      <div className="flex flex-col justify-between h-[50px] w-6 flex-shrink-0">
        <div className="w-6 h-6 relative group">
           {/* Home Logo (Top) */}
           <div className="absolute inset-0 bg-indigo-500/20 blur-sm rounded-full opacity-50"></div>
           <img src={homeTeamLogo} alt="Home" className="w-full h-full object-contain relative z-10" />
        </div>
        <div className="w-6 h-6 relative group">
           {/* Away Logo (Bottom) */}
           <div className="absolute inset-0 bg-emerald-500/20 blur-sm rounded-full opacity-50"></div>
           <img src={awayTeamLogo} alt="Away" className="w-full h-full object-contain relative z-10" />
        </div>
      </div>

      {/* RIGHT COLUMN: Graph Container */}
      <div className="relative h-[60px] flex-1 rounded-lg border border-white/10 bg-white/5 backdrop-blur-sm overflow-visible">

        {/* --- Graph Content (Clipped) --- */}
        <div className="absolute inset-0 rounded-lg overflow-hidden">
          
          {/* Zero Line */}
          <div className="absolute top-1/2 left-0 right-0 h-[1px] bg-white/10 z-0"></div>

          {/* 15-Minute Grid Lines (Every 16.66% approx of 90min) */}
          {[15, 30, 45, 60, 75].map((min) => {
             const leftPos = (min / maxTime) * 100;
             return (
               <div 
                 key={min}
                 className={`absolute top-0 bottom-0 w-[0.5px] z-0 ${min === 45 ? 'bg-white/30 border-r border-dashed border-white/30' : 'bg-white/5'}`} 
                 style={{ left: `${leftPos}%` }}
               >
                  {/* 45min label */}
                  {min === 45 && <span className="text-[7px] text-white/30 font-mono ml-1 mt-1 block">HT</span>}
               </div>
             );
          })}

          {/* SVG Graph */}
          <svg 
            viewBox={`0 0 ${width} ${height}`} 
            preserveAspectRatio="none" 
            className="w-full h-full absolute inset-0 pointer-events-none z-10"
          >
            <defs>
               {/* Liquid Neon Glow Filter */}
               <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
                 <feGaussianBlur stdDeviation="1.5" result="coloredBlur" />
                 <feMerge>
                   <feMergeNode in="coloredBlur" />
                   <feMergeNode in="SourceGraphic" />
                 </feMerge>
               </filter>

               <linearGradient id="momentumGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366F1" stopOpacity="1" />
                  <stop offset="40%" stopColor="#6366F1" stopOpacity="0.4" />
                  <stop offset="48%" stopColor="#6366F1" stopOpacity="0" />
                  <stop offset="52%" stopColor="#10B981" stopOpacity="0" />
                  <stop offset="60%" stopColor="#10B981" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#10B981" stopOpacity="1" />
               </linearGradient>
            </defs>
            
            <path 
              d={pathD} 
              fill="url(#momentumGradient)" 
              stroke="none"
              filter="url(#neonGlow)"
              className="transition-all duration-500 ease-out"
            />
             <path 
              d={pathD} 
              fill="none" 
              stroke="url(#momentumGradient)"
              strokeWidth="1"
              strokeOpacity="1"
              strokeLinecap="round"
            />
          </svg>

          {/* Live Pulsing Beacon */}
          <div 
            className="absolute top-0 bottom-0 w-8 bg-gradient-to-l from-space/50 to-transparent z-20 pointer-events-none flex items-center justify-end px-0 translate-x-1/2"
            style={{ left: `${currentProgressPercent}%` }}
          >
             <div className={`w-2 h-2 rounded-full ${currentMomentum > 0 ? 'bg-indigo-400 shadow-[0_0_15px_#6366F1]' : 'bg-emerald-400 shadow-[0_0_15px_#10B981]'} animate-pulse`}></div>
          </div>
        </div>

        {/* --- Event Markers (Not Clipped) --- */}
        <div className="absolute inset-0 z-20 pointer-events-none">
          {events.map((event) => {
            const leftPercent = Math.min(100, Math.max(0, (event.minute / maxTime) * 100));
            const isHome = event.teamId === homeTeamId;
            const isActive = activeEventId === event.id;
            const topPercent = isHome ? 25 : 75; 
            const isNearStart = leftPercent < 15;
            const isNearEnd = leftPercent > 85;

            return (
              <div 
                key={event.id}
                onClick={(e) => { e.stopPropagation(); setActiveEventId(isActive ? null : event.id); }}
                className="absolute transform -translate-x-1/2 -translate-y-1/2 pointer-events-auto cursor-pointer transition-transform active:scale-95"
                style={{ left: `${leftPercent}%`, top: `${topPercent}%`, zIndex: isActive ? 100 : 20 }}
              >
                {event.type === 'GOAL' && <SoccerBall />}
                {event.type === 'YELLOW_CARD' && <div className="w-2 h-3 bg-yellow-400 rounded-[1px] shadow-sm border-[0.5px] border-white/30" />}
                {event.type === 'RED_CARD' && <div className="w-2 h-3 bg-rose-600 rounded-[1px] shadow-sm border-[0.5px] border-white/30" />}
                {event.type === 'PENALTY_SCORED' && <div className="w-3 h-3 rounded-full border border-emerald-400 bg-emerald-500/20 flex items-center justify-center"><Circle className="w-2 h-2 text-emerald-400 fill-emerald-400" /></div>}
                {event.type === 'PENALTY_MISSED' && <div className="w-3 h-3 rounded-full border border-rose-400 bg-rose-500/20 flex items-center justify-center"><X className="w-2 h-2 text-rose-400" /></div>}

                {/* Tooltip */}
                <div className={`
                  absolute bg-[#0A0E27] border border-white/10 text-[9px] text-white px-2 py-1 rounded 
                  transition-all duration-200 whitespace-nowrap shadow-xl
                  ${isActive ? 'opacity-100 translate-y-0 visible' : 'opacity-0 invisible translate-y-1 pointer-events-none'}
                  ${isHome ? 'top-full mt-2' : 'bottom-full mb-2'}
                  ${isNearStart ? 'left-0 translate-x-[-2px]' : ''}
                  ${isNearEnd ? 'right-0 translate-x-[2px]' : ''}
                  ${!isNearStart && !isNearEnd ? 'left-1/2 -translate-x-1/2' : ''}
                `}>
                  <span className="font-bold text-indigo-400">{event.minute}'</span> {event.playerName}
                  <div className={`absolute w-0 h-0 border-4 border-transparent ${!isNearStart && !isNearEnd ? 'left-1/2 -translate-x-1/2' : ''} ${isNearStart ? 'left-1.5' : ''} ${isNearEnd ? 'right-1.5' : ''} ${isHome ? 'bottom-full border-b-white/10' : 'top-full border-t-white/10'}`} />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
