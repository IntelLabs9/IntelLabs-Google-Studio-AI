import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Trophy, Star, CalendarDays, Target, Flag, ChevronLeft, Sparkles, TrendingUp, Shield, Users, CheckCircle2, AlertCircle, ChevronDown, Layers } from 'lucide-react';
import { Match, FormResult, TeamLineup, Player, LeagueStanding, HistoricMatch } from '../types';
import { NebulaTracker } from './NebulaTracker';
import { NeuroPulseButton } from './NeuroPulseButton';
import { MOCK_STANDINGS, MOCK_HISTORY } from '../constants';

interface MatchCardProps {
  match: Match;
  onToggleFavorite: (id: string) => void;
  onBack: () => void;
  activeTab: 'details' | 'manager' | 'standings';
  onTabChange: (tab: 'details' | 'manager' | 'standings') => void;
}

// Custom Whistle Icon for "Cards" (Referee)
const WhistleIcon = ({ className }: { className?: string }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M11 3a8 8 0 0 1 8 8v7a1 1 0 0 1-1 1h-5.5V8a2.5 2.5 0 1 0-5 0v11H6a1 1 0 0 1-1-1V11a8 8 0 0 1 6-8z" />
    <path d="M7.5 19H11" />
    <path d="M6 11h.01" />
  </svg>
);

const FormRow: React.FC<{ form: FormResult[] }> = ({ form }) => (
  <div className="flex gap-1.5 justify-center">
    {form.map((item, idx) => (
      <div
        key={idx}
        className="relative group/tooltip"
      >
        <div
          className={`
            w-6 h-6 rounded-full flex items-center justify-center overflow-hidden bg-white/5
            border-[1.5px] cursor-pointer
            ${item.result === 'W' ? 'border-emerald-500 shadow-[0_0_6px_rgba(16,185,129,0.4)]' : ''}
            ${item.result === 'L' ? 'border-rose-500 shadow-[0_0_6px_rgba(244,63,94,0.4)]' : ''}
            ${item.result === 'D' ? 'border-gray-500' : ''}
          `}
        >
          <img src={item.opponentLogo} alt="Opponent" className="w-full h-full object-cover opacity-90" />
        </div>
        
        {/* Custom Tooltip */}
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover/tooltip:opacity-100 transition-opacity duration-200 pointer-events-none z-50">
          <div className="bg-[#0A0E27] border border-white/10 text-white text-[10px] font-bold px-2 py-1 rounded shadow-xl whitespace-nowrap">
            ( {item.isHome ? 'H' : 'A'} | {item.score} )
            <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-[#0A0E27]" />
          </div>
        </div>
      </div>
    ))}
  </div>
);

const ActivityIcon = ({ className }: { className?: string }) => (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
    </svg>
);

// --- LIVE STATS ANIMATION COMPONENTS ---

const useStatChange = (value: any) => {
  const [changed, setChanged] = useState(false);
  const prevValue = useRef(value);

  useEffect(() => {
    const isDifferent = typeof value === 'object' 
      ? JSON.stringify(value) !== JSON.stringify(prevValue.current)
      : value !== prevValue.current;

    if (isDifferent) {
      setChanged(true);
      prevValue.current = value;
      const timer = setTimeout(() => setChanged(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [value]);

  return changed;
};

const LiveStatRow: React.FC<{
  icon: React.ElementType;
  label: string;
  homeValue: React.ReactNode;
  awayValue: React.ReactNode;
  homeRaw: any;
  awayRaw: any;
}> = ({ icon: Icon, label, homeValue, awayValue, homeRaw, awayRaw }) => {
  const homeChanged = useStatChange(homeRaw);
  const awayChanged = useStatChange(awayRaw);

  return (
    <div className="contents">
      {/* Home Value */}
      <div className={`relative flex items-center justify-center rounded-lg transition-all duration-500 ${homeChanged ? 'bg-indigo-500/10 scale-105' : ''}`}>
        {homeChanged && (
          <>
            <div className="absolute inset-0 bg-indigo-500/20 blur-md rounded-lg animate-pulse" />
            <div className="absolute inset-0 overflow-hidden rounded-lg">
               <div className="absolute inset-0 bg-gradient-to-r from-transparent via-indigo-400/20 to-transparent -translate-x-full animate-[shimmer_1s_linear]" />
            </div>
          </>
        )}
        <span className={`text-sm font-bold text-center tabular-nums transition-colors duration-300 ${homeChanged ? 'text-indigo-300 drop-shadow-[0_0_8px_rgba(99,102,241,0.8)]' : 'text-indigo-300'}`}>
          {homeValue}
        </span>
      </div>

      {/* Label (Brightened Text Color) */}
      <div className="flex items-center justify-center gap-1.5 text-[10px] font-tech uppercase tracking-tight">
        <Icon className={`w-3.5 h-3.5 transition-colors duration-300 ${homeChanged ? 'text-indigo-400' : awayChanged ? 'text-emerald-400' : 'text-white/90'}`} />
        <span className={`transition-colors duration-300 font-medium ${homeChanged || awayChanged ? 'text-white' : 'text-indigo-100/90'}`}>{label}</span>
      </div>

      {/* Away Value */}
      <div className={`relative flex items-center justify-center rounded-lg transition-all duration-500 ${awayChanged ? 'bg-emerald-500/10 scale-105' : ''}`}>
        {awayChanged && (
          <>
            <div className="absolute inset-0 bg-emerald-500/20 blur-md rounded-lg animate-pulse" />
            <div className="absolute inset-0 overflow-hidden rounded-lg">
               <div className="absolute inset-0 bg-gradient-to-r from-transparent via-emerald-400/20 to-transparent -translate-x-full animate-[shimmer_1s_linear]" />
            </div>
          </>
        )}
        <span className={`text-sm font-bold text-center tabular-nums transition-colors duration-300 ${awayChanged ? 'text-emerald-300 drop-shadow-[0_0_8px_rgba(16,185,129,0.8)]' : 'text-emerald-300'}`}>
          {awayValue}
        </span>
      </div>
    </div>
  );
};

// --- ELITE PLAYERS SECTION --- (Unchanged)
const ELITE_POSITIONS = [
  { id: 'Forward', label: 'Striker', keywords: ['ST', 'CF', 'RW', 'LW', 'FW'] },
  { id: 'Midfield', label: 'Midfielder', keywords: ['CM', 'CDM', 'CAM', 'MF', 'LM', 'RM'] },
  { id: 'Defense', label: 'Defender', keywords: ['CB', 'RB', 'LB', 'DF'] }
];

const ElitePlayersSection: React.FC<{ homeLineup?: TeamLineup; awayLineup?: TeamLineup }> = ({ homeLineup, awayLineup }) => {
  const [activePosition, setActivePosition] = useState(ELITE_POSITIONS[0].id);

  const getKeyPlayer = (lineup: TeamLineup | undefined, positionId: string) => {
    if (!lineup) return null;
    const category = ELITE_POSITIONS.find(p => p.id === positionId);
    if (!category) return null;

    const playersInPos = lineup.starting.filter(p => category.keywords.includes(p.position));
    return playersInPos.sort((a, b) => (b.rating || 0) - (a.rating || 0))[0] || null;
  };

  const homePlayer = useMemo(() => getKeyPlayer(homeLineup, activePosition), [homeLineup, activePosition]);
  const awayPlayer = useMemo(() => getKeyPlayer(awayLineup, activePosition), [awayLineup, activePosition]);

  if (!homePlayer || !awayPlayer) return null;

  const renderStats = () => {
    const statsMap: Record<string, { label: string; key: string; default: string }[]> = {
      'Forward': [
        { label: 'Goals', key: 'goals', default: '0' },
        { label: 'Assists', key: 'assists', default: '0' },
        { label: 'Shots/90', key: 'shotsPerGame', default: '0.0' }
      ],
      'Midfield': [
        { label: 'Assists', key: 'assists', default: '0' },
        { label: 'Pass Acc %', key: 'passAccuracy', default: '80' },
        { label: 'Goals', key: 'goals', default: '0' }
      ],
      'Defense': [
        { label: 'Tackles/90', key: 'tacklesPerGame', default: '0.0' },
        { label: 'Intercepts', key: 'interceptions', default: '0.0' },
        { label: 'Clean Sheets', key: 'cleanSheets', default: '0' }
      ]
    };

    const currentStats = statsMap[activePosition] || statsMap['Forward'];

    return (
      <div className="flex flex-col gap-3 w-full px-2">
        {currentStats.map((stat, idx) => (
          <div key={idx} className="flex items-center justify-between text-[10px]">
            <span className="font-bold text-white text-xs w-8 text-right">
              {homePlayer.seasonStats?.[stat.key] ?? stat.default}
            </span>
            <div className="flex-1 text-center px-2">
              <span className="text-white/40 uppercase tracking-wider">{stat.label}</span>
            </div>
            <span className="font-bold text-white text-xs w-8 text-left">
              {awayPlayer.seasonStats?.[stat.key] ?? stat.default}
            </span>
          </div>
        ))}
        <div className="flex items-center justify-between mt-1">
            <div className="bg-emerald-500 text-[#0A0E27] px-2 py-0.5 rounded text-xs font-bold shadow-[0_0_10px_rgba(16,185,129,0.4)]">
                {homePlayer.rating || '7.0'}
            </div>
            <span className="text-white/40 uppercase tracking-wider text-[10px]">Rating</span>
             <div className="bg-amber-500 text-[#0A0E27] px-2 py-0.5 rounded text-xs font-bold shadow-[0_0_10px_rgba(245,158,11,0.4)]">
                {awayPlayer.rating || '7.0'}
            </div>
        </div>
      </div>
    );
  };

  return (
    <div className="animate-in slide-in-from-bottom-6 duration-700 delay-200">
        <h3 className="text-[10px] font-bold text-white/60 uppercase tracking-widest mb-3 ml-1">Elite Players</h3>
        <div className="bg-white/5 rounded-xl border border-white/5 p-4 overflow-hidden relative">
             <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-32 bg-indigo-500/10 blur-3xl rounded-full pointer-events-none" />
            <div className="flex bg-black/20 p-1 rounded-lg mb-6 border border-white/5 relative z-10">
                {ELITE_POSITIONS.map((pos) => (
                    <button
                        key={pos.id}
                        onClick={() => setActivePosition(pos.id)}
                        className={`flex-1 py-1.5 text-[9px] font-bold uppercase tracking-wider rounded-md transition-all duration-300 ${
                            activePosition === pos.id 
                            ? 'bg-indigo-500 text-white shadow-lg' 
                            : 'text-white/40 hover:text-white/70'
                        }`}
                    >
                        {pos.label}
                    </button>
                ))}
            </div>
            <div className="flex items-center justify-between relative z-10">
                <div className="flex flex-col items-center gap-2 w-1/3">
                    <div className="relative w-14 h-14">
                        <div className="absolute inset-0 bg-indigo-500/20 rounded-full blur-md" />
                        <img src={homePlayer.imageUrl} alt={homePlayer.name} className="w-full h-full object-cover rounded-full border-2 border-indigo-400/50 relative z-10 shadow-lg" />
                    </div>
                    <div className="text-center">
                        <span className="text-xs font-bold text-white block leading-tight">{homePlayer.name.split(' ').pop()}</span>
                        <span className="text-[9px] text-indigo-300/60 font-mono">{homePlayer.position}</span>
                    </div>
                </div>
                <div className="flex-1 flex flex-col items-center">{renderStats()}</div>
                <div className="flex flex-col items-center gap-2 w-1/3">
                     <div className="relative w-14 h-14">
                        <div className="absolute inset-0 bg-amber-500/20 rounded-full blur-md" />
                        <img src={awayPlayer.imageUrl} alt={awayPlayer.name} className="w-full h-full object-cover rounded-full border-2 border-amber-400/50 relative z-10 shadow-lg" />
                    </div>
                     <div className="text-center">
                        <span className="text-xs font-bold text-white block leading-tight">{awayPlayer.name.split(' ').pop()}</span>
                        <span className="text-[9px] text-amber-300/60 font-mono">{awayPlayer.position}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

// --- PITCH VISUALIZATION COMPONENTS ---

const PitchPlayer: React.FC<{ player: Player; style?: React.CSSProperties; isHome?: boolean }> = ({ player, style, isHome = true }) => (
  <div 
    className="absolute flex flex-col items-center transform -translate-x-1/2 -translate-y-1/2 w-16 transition-all duration-500 z-10"
    style={style}
  >
    <div className="relative w-9 h-9 group cursor-pointer mb-1">
      {/* Shadow */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-6 h-1.5 bg-black/40 blur-sm rounded-full" />
      
      {/* Player Image Container */}
      <div className={`w-full h-full rounded-full overflow-hidden border-2 border-white bg-gray-800 relative z-10 shadow-lg transition-all duration-300 ease-out group-hover:scale-110 ${isHome ? 'group-hover:border-indigo-400 group-hover:shadow-[0_0_15px_rgba(99,102,241,0.6)]' : 'group-hover:border-emerald-400 group-hover:shadow-[0_0_15px_rgba(16,185,129,0.6)]'}`}>
        <img src={player.imageUrl} alt={player.name} className="w-full h-full object-cover" />
      </div>

      {/* Number Badge */}
       <div className={`absolute -top-1 -right-1 text-white text-[8px] font-bold w-3.5 h-3.5 rounded-full flex items-center justify-center border border-white z-20 shadow ${isHome ? 'bg-indigo-600' : 'bg-emerald-600'}`}>
         {player.number}
       </div>
    </div>

    {/* Name & Score Label (Fixed, No Tooltip) */}
    <div className="flex items-center gap-1 px-1.5 py-0.5 bg-[#0A0E27]/90 backdrop-blur-md rounded-full border border-white/10 shadow-md whitespace-nowrap">
      <span className={`text-[9px] font-bold leading-none ${player.rating && player.rating >= 7.5 ? 'text-emerald-400' : 'text-indigo-300'}`}>
        {player.rating || '-'}
      </span>
      <div className="w-[1px] h-2 bg-white/20"></div>
      <span className="text-[8px] text-white font-medium truncate max-w-[60px] leading-none">
        {player.name.split(' ').pop()}
      </span>
    </div>
  </div>
);

const Pitch: React.FC<{ lineup: TeamLineup; isHome?: boolean }> = ({ lineup, isHome = true }) => {
  const formationParts = lineup.formation.split('-').map(Number); 
  const rows = [1, ...formationParts]; 
  let playerIndex = 0;

  return (
    <div className="relative w-[95%] mx-auto aspect-[3/4] bg-emerald-900/20 rounded-xl overflow-hidden border border-white/5 shadow-2xl">
      
      {/* Field Graphic */}
      <div className="absolute inset-0 flex flex-col">
         <div className="absolute inset-0 opacity-30 bg-[repeating-linear-gradient(0deg,transparent,transparent_24px,#ffffff05_25px,#ffffff05_49px)]" />
         <div className="absolute inset-0 bg-gradient-to-b from-emerald-800/40 to-emerald-600/40" />
         <div className="absolute top-0 left-4 right-4 h-px bg-white/20" />
         <div className="absolute bottom-0 left-4 right-4 h-px bg-white/20" />
         <div className="absolute top-0 bottom-0 left-4 w-px bg-white/20" />
         <div className="absolute top-0 bottom-0 right-4 w-px bg-white/20" />
         <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 rounded-full border border-white/20" />
         <div className="absolute top-1/2 left-4 right-4 h-px bg-white/20" />
         <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-48 h-24 border border-white/20 border-b-0 bg-white/5" />
         <div className="absolute top-4 left-1/2 -translate-x-1/2 w-48 h-24 border border-white/20 border-t-0 bg-white/5" />
         <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-20 h-8 border border-white/20 border-b-0" />
         <div className="absolute top-4 left-1/2 -translate-x-1/2 w-20 h-8 border border-white/20 border-t-0" />
      </div>

      {/* Players */}
      <div className="absolute top-4 bottom-4 left-12 right-12">
        {rows.map((count, rowIndex) => {
          const totalRows = rows.length;
          const yPercent = 88 - (rowIndex * (76 / (totalRows - 1)));

          const playersInRow = [];
          for (let i = 0; i < count; i++) {
             if (playerIndex < lineup.starting.length) {
               playersInRow.push(lineup.starting[playerIndex]);
               playerIndex++;
             }
          }

          return (
            <React.Fragment key={rowIndex}>
              {playersInRow.map((player, colIndex) => {
                // Maximized Horizontal Distribution: 0% to 100% of the safe zone
                const xPercent = count === 1 ? 50 : (colIndex / (count - 1)) * 100;
                
                return (
                  <PitchPlayer 
                    key={player.id} 
                    player={player} 
                    isHome={isHome}
                    style={{ left: `${xPercent}%`, top: `${yPercent}%` }} 
                  />
                );
              })}
            </React.Fragment>
          );
        })}
      </div>

       {/* Formation Label */}
       <div className="absolute bottom-2 left-3 bg-black/40 backdrop-blur-md px-2 py-1 rounded text-[10px] text-white/80 font-mono border border-white/10">
          {lineup.formation}
       </div>
    </div>
  );
};

// ... (Rest of the file: SquadList, MatchesHistory, MatchCard)
const SquadList: React.FC<{ title: string; items: Player[] | { name: string; imageUrl: string; position?: string; number?: number }[] }> = ({ title, items }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="bg-white/5 rounded-xl border border-white/5 overflow-hidden transition-all duration-300">
        <button 
          onClick={() => setIsOpen(!isOpen)}
          className="w-full bg-white/5 px-3 py-3 flex items-center justify-between text-[10px] font-bold text-white/60 uppercase tracking-widest border-b border-white/5 hover:bg-white/10 transition-colors"
        >
            <span>{title}</span>
            <ChevronDown className={`w-4 h-4 transition-transform duration-300 text-white/40 ${isOpen ? 'rotate-180' : ''}`} />
        </button>
        
        <div className={`transition-all duration-500 ease-in-out overflow-hidden ${isOpen ? 'max-h-[1000px] opacity-100' : 'max-h-0 opacity-0'}`}>
            <div className="grid grid-cols-2">
                {items.map((item, idx) => (
                    <div 
                      key={idx} 
                      className={`
                        flex items-center gap-2 p-2 hover:bg-white/5 transition-colors border-b border-white/5
                        ${idx % 2 === 0 ? 'border-r' : ''}
                      `}
                    >
                        <div className="relative flex-shrink-0">
                            <img src={item.imageUrl} alt={item.name} className="w-8 h-8 rounded-full object-cover bg-gray-800" />
                            {/* Badge indicator if Manager or Player? Assuming player structure mostly */}
                            {'id' in item && (
                              <div className="absolute -top-1 -right-1 bg-white/10 text-white text-[8px] w-3.5 h-3.5 rounded-full flex items-center justify-center border border-white/10">
                                  <span className="font-mono">{(item as Player).number || '+'}</span>
                              </div>
                            )}
                        </div>
                        <div className="min-w-0 overflow-hidden">
                            <p className="text-xs text-white font-medium truncate">{item.name}</p>
                            <p className="text-[9px] text-white/40 uppercase tracking-wider truncate">
                              {'position' in item ? (item as Player).position : 'Coach'}
                            </p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    </div>
  );
};

// --- HISTORY LIST COMPONENT ---
const MatchesHistory: React.FC<{ matches: HistoricMatch[], teamId: string }> = ({ matches, teamId }) => {
  return (
    <div className="space-y-0">
      {matches.map((match) => (
        <div key={match.id} className="flex items-center justify-between p-3 border-b border-white/5 hover:bg-white/5 transition-colors last:border-0">
          {/* Date */}
          <div className="w-16 text-[10px] text-white/40 font-mono">{match.date}</div>
          
          {/* Match Info */}
          <div className="flex-1 flex items-center justify-center gap-3">
             <span className={`text-xs font-bold ${match.homeTeam.includes('Chelsea') || match.homeTeam.includes('Burnley') ? 'text-white' : 'text-white/60'}`}>
                {match.homeTeam}
             </span>
             <div className="px-2 py-0.5 bg-white/10 rounded text-[10px] font-mono font-bold text-white">
                {match.homeScore} - {match.awayScore}
             </div>
             <span className={`text-xs font-bold ${match.awayTeam.includes('Chelsea') || match.awayTeam.includes('Burnley') ? 'text-white' : 'text-white/60'}`}>
                {match.awayTeam}
             </span>
          </div>

          {/* Result Indicator */}
          <div className="w-6 flex justify-end">
             <div className={`w-5 h-5 rounded flex items-center justify-center text-[10px] font-bold ${
               match.result === 'W' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
               match.result === 'L' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' :
               'bg-white/10 text-white/60 border border-white/20'
             }`}>
               {match.result}
             </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export const MatchCard: React.FC<MatchCardProps> = ({ match, onToggleFavorite, onBack, activeTab, onTabChange }) => {
  const matchDuration = match.isLive ? (parseInt(match.time.replace("'", "")) || 90) : 90;
  
  // Manager Tab State
  const [selectedTeamId, setSelectedTeamId] = useState<string>(match.homeTeam.id);
  const selectedTeam = selectedTeamId === match.homeTeam.id ? match.homeTeam : match.awayTeam;
  const selectedLineup = selectedTeam.lineup;

  // Standings Tab State
  const [matchesView, setMatchesView] = useState<'home' | 'h2h' | 'away'>('h2h');

  return (
    <div className="min-h-screen bg-[#0A0E27] pb-32 relative">
      
      {/* FIXED HEADER SECTION (Nav + Score + Tabs) */}
      <div className="fixed top-0 left-0 right-0 mx-auto max-w-md z-50 bg-[#0A0E27]/95 backdrop-blur-xl border-b border-white/5 shadow-2xl transition-all duration-300">
        
        {/* Top Navigation Bar */}
        <div className="flex justify-between items-center px-4 py-3">
          <button 
            onClick={onBack}
            className="p-2 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 active:scale-95 transition-all"
          >
            <ChevronLeft className="w-5 h-5 text-white" />
          </button>
          
          <div className="flex items-center gap-2 text-white/60 text-xs font-bold tracking-wider uppercase">
            <Trophy className="w-3 h-3 text-indigo-400" />
            {match.league} <span className="text-white/30 mx-1">•</span> <span className="text-white/40 font-normal">{match.date}</span>
          </div>

          <button 
            onClick={() => onToggleFavorite(match.id)}
            className="p-2 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 active:scale-95 transition-all"
          >
            <Star 
              className={`w-4 h-4 transition-all duration-300 ${
                match.isFavorite 
                  ? 'fill-yellow-400 text-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.5)]' 
                  : 'text-white/20'
              }`} 
            />
          </button>
        </div>

        {/* Scoreboard */}
        <div className="px-4 pb-2 pt-1">
           <div className="flex items-center justify-between">
              {/* Home */}
              <div className="flex flex-col items-center w-1/3">
                <img src={match.homeTeam.logoUrl} alt={match.homeTeam.name} className="w-12 h-12 object-contain drop-shadow-lg" />
                <span className="text-white font-bold text-xs mt-1 truncate w-full text-center">{match.homeTeam.name}</span>
              </div>

              {/* Score & Time */}
              <div className="flex flex-col items-center w-1/3">
                 {match.isLive ? (
                    <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-rose-500/10 border border-rose-500/20 mb-1">
                      <div className="w-1.5 h-1.5 bg-rose-500 rounded-full animate-pulse" />
                      <span className="text-rose-400 text-[10px] font-mono font-bold">{match.time}</span>
                    </div>
                 ) : (
                    <div className="px-2 py-0.5 rounded-full bg-white/5 border border-white/10 mb-1">
                      <span className="text-white/60 text-[10px] font-mono">{match.time}</span>
                    </div>
                 )}
                 <div className="text-3xl font-tech font-bold text-white tracking-widest">
                    {match.homeTeam.score} - {match.awayTeam.score}
                 </div>
              </div>

              {/* Away */}
              <div className="flex flex-col items-center w-1/3">
                <img src={match.awayTeam.logoUrl} alt={match.awayTeam.name} className="w-12 h-12 object-contain drop-shadow-lg" />
                <span className="text-white font-bold text-xs mt-1 truncate w-full text-center">{match.awayTeam.name}</span>
              </div>
           </div>
        </div>

        {/* Temporal Navigation (Tabs) */}
        <div className="flex items-center justify-center pt-2">
           <div className="flex w-full px-4 relative">
             <button 
                onClick={() => onTabChange('details')}
                className={`flex-1 pb-3 text-center text-[10px] sm:text-xs font-bold uppercase tracking-wider transition-all duration-300 relative ${activeTab === 'details' ? 'text-white' : 'text-white/40 hover:text-white/60'}`}
             >
                Insights
                {activeTab === 'details' && (
                   <div className="absolute bottom-0 left-0 right-0 h-[3px] bg-indigo-500 rounded-t-full shadow-[0_-2px_10px_rgba(99,102,241,0.5)] animate-in fade-in zoom-in duration-300" />
                )}
             </button>
             <button 
                onClick={() => onTabChange('manager')}
                className={`flex-1 pb-3 text-center text-[10px] sm:text-xs font-bold uppercase tracking-wider transition-all duration-300 relative ${activeTab === 'manager' ? 'text-white' : 'text-white/40 hover:text-white/60'}`}
             >
                Manager
                {activeTab === 'manager' && (
                   <div className="absolute bottom-0 left-0 right-0 h-[3px] bg-emerald-500 rounded-t-full shadow-[0_-2px_10px_rgba(16,185,129,0.5)] animate-in fade-in zoom-in duration-300" />
                )}
             </button>
             <button 
                onClick={() => onTabChange('standings')}
                className={`flex-1 pb-3 text-center text-[10px] sm:text-xs font-bold uppercase tracking-wider transition-all duration-300 relative ${activeTab === 'standings' ? 'text-white' : 'text-white/40 hover:text-white/60'}`}
             >
                Standings
                {activeTab === 'standings' && (
                   <div className="absolute bottom-0 left-0 right-0 h-[3px] bg-amber-500 rounded-t-full shadow-[0_-2px_10px_rgba(245,158,11,0.5)] animate-in fade-in zoom-in duration-300" />
                )}
             </button>
             {/* Bottom Border Line for Tab Container */}
             <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-white/5 z-[-1]" />
           </div>
        </div>
      </div>

      {/* SCROLLABLE CONTENT */}
      <div className="px-4 pt-[176px] space-y-6">
        
        {/* --- TAB: DETAILS --- */}
        {activeTab === 'details' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Form Rows */}
            {match.isLive && (
              <div className="mb-2">
                <h3 className="text-xs font-bold text-white/40 uppercase tracking-widest mb-3 ml-1 flex items-center gap-2">
                  <TrendingUp className="w-3 h-3" /> Form
                </h3>
                <div className="flex justify-between px-2">
                  <div className="w-1/3 flex justify-center"><FormRow form={match.homeTeam.form} /></div>
                  <div className="w-1/3"></div>
                  <div className="w-1/3 flex justify-center"><FormRow form={match.awayTeam.form} /></div>
                </div>
              </div>
            )}

            {/* Nebula Momentum Tracker */}
            <div>
              <h3 className="text-xs font-bold text-white/40 uppercase tracking-widest mb-3 ml-1 flex items-center gap-2">
                <Target className="w-3 h-3" /> Momentum
              </h3>
              <NebulaTracker 
                history={match.momentumHistory} 
                currentMomentum={match.momentum}
                events={match.events}
                matchDuration={matchDuration}
                homeTeamId={match.homeTeam.id}
                awayTeamId={match.awayTeam.id}
                homeTeamLogo={match.homeTeam.logoUrl}
                awayTeamLogo={match.awayTeam.logoUrl}
              />
            </div>

            {/* Live Stats Grid (REACTIVE) */}
            {match.isLive ? (
              <div className="animate-in fade-in slide-in-from-bottom-2 duration-700">
                <h3 className="text-xs font-bold text-white/40 uppercase tracking-widest mb-3 ml-1 flex items-center gap-2">
                <ActivityIcon className="w-3 h-3" /> Live Stats
                </h3>
                
                {/* Possession Bar */}
                <div className="flex flex-col gap-1.5 mb-4 px-1">
                  <div className="flex justify-between text-[9px] text-white/60 font-tech tracking-wider uppercase">
                    <span>{match.stats.homePossession}% Possession</span>
                    <span>{match.stats.awayPossession}%</span>
                  </div>
                  <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden flex">
                    <div style={{ width: `${match.stats.homePossession}%` }} className="h-full bg-indigo-500 shadow-[0_0_10px_rgba(99,102,241,0.5)]" />
                    <div style={{ width: `${match.stats.awayPossession}%` }} className="h-full bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]" />
                  </div>
                </div>

                {/* Detailed Stats Grid - UPDATED with LiveStatRow */}
                <div className="grid grid-cols-3 gap-y-4 py-4 px-3 bg-white/5 rounded-xl border border-white/5 backdrop-blur-sm shadow-inner relative overflow-hidden">
                  
                  <LiveStatRow 
                    icon={Target} 
                    label="Shots (On Goal)" 
                    homeValue={<>{match.stats.homeShots} <span className="text-[10px] opacity-60 font-medium">({match.stats.homeOnTarget})</span></>}
                    awayValue={<>{match.stats.awayShots} <span className="text-[10px] opacity-60 font-medium">({match.stats.awayOnTarget})</span></>}
                    homeRaw={match.stats.homeShots}
                    awayRaw={match.stats.awayShots}
                  />

                  <LiveStatRow 
                    icon={Flag} 
                    label="Corners" 
                    homeValue={match.stats.homeCorners}
                    awayValue={match.stats.awayCorners}
                    homeRaw={match.stats.homeCorners}
                    awayRaw={match.stats.awayCorners}
                  />

                  <LiveStatRow 
                    icon={WhistleIcon} 
                    label="Cards" 
                    homeValue={
                      <div className="flex gap-1 items-center justify-center">
                        {match.stats.homeYellowCards > 0 && <div className="w-3 h-4 bg-yellow-400/90 rounded-[2px] flex items-center justify-center text-[9px] text-black font-bold shadow-sm">{match.stats.homeYellowCards}</div>}
                        {match.stats.homeRedCards > 0 && <div className="w-3 h-4 bg-rose-500/90 rounded-[2px] flex items-center justify-center text-[9px] text-white font-bold shadow-sm">{match.stats.homeRedCards}</div>}
                        {match.stats.homeYellowCards === 0 && match.stats.homeRedCards === 0 && <span className="text-[10px] opacity-40">-</span>}
                      </div>
                    }
                    awayValue={
                      <div className="flex gap-1 items-center justify-center">
                        {match.stats.awayYellowCards > 0 && <div className="w-3 h-4 bg-yellow-400/90 rounded-[2px] flex items-center justify-center text-[9px] text-black font-bold shadow-sm">{match.stats.awayYellowCards}</div>}
                        {match.stats.awayRedCards > 0 && <div className="w-3 h-4 bg-rose-500/90 rounded-[2px] flex items-center justify-center text-[9px] text-white font-bold shadow-sm">{match.stats.awayRedCards}</div>}
                        {match.stats.awayYellowCards === 0 && match.stats.awayRedCards === 0 && <span className="text-[10px] opacity-40">-</span>}
                      </div>
                    }
                    homeRaw={{ y: match.stats.homeYellowCards, r: match.stats.homeRedCards }}
                    awayRaw={{ y: match.stats.awayYellowCards, r: match.stats.awayRedCards }}
                  />

                </div>
              </div>
            ) : (
              <div className="animate-in fade-in slide-in-from-bottom-2 duration-700">
                <h3 className="text-xs font-bold text-white/40 uppercase tracking-widest mb-3 ml-1 flex items-center gap-2">
                    <ActivityIcon className="w-3 h-3" /> Pre-Match Stats
                </h3>
                <div className="bg-white/5 rounded-xl border border-white/5 backdrop-blur-sm shadow-inner p-4 space-y-6">
                    <div>
                        <div className="flex items-center gap-2 mb-3">
                            <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider">Team Form</span>
                            <div className="h-[1px] flex-1 bg-white/10"></div>
                        </div>
                        <div className="flex justify-between items-center">
                            <div className="flex flex-col items-center gap-2">
                                <span className="text-[9px] text-white/60 font-bold uppercase">{match.homeTeam.name}</span>
                                <FormRow form={match.homeTeam.form} />
                            </div>
                            <div className="h-8 w-[1px] bg-white/10 mx-2"></div>
                            <div className="flex flex-col items-center gap-2">
                                <span className="text-[9px] text-white/60 font-bold uppercase">{match.awayTeam.name}</span>
                                <FormRow form={match.awayTeam.form} />
                            </div>
                        </div>
                    </div>
                    <div>
                        <div className="flex items-center gap-2 mb-3">
                            <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
                            <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">Elite Insights</span>
                            <div className="h-[1px] flex-1 bg-white/10"></div>
                        </div>
                        <div className="space-y-2">
                            {match.trends && match.trends.length > 0 ? (
                                match.trends.map((trend, i) => (
                                    <div key={i} className="flex gap-3 items-start p-2.5 rounded-lg bg-[#0A0E27]/50 border border-white/5 hover:border-amber-500/30 transition-colors group">
                                        <div className="mt-1.5 min-w-[6px] h-[6px] rounded-full bg-indigo-500 shadow-[0_0_8px_#6366F1] group-hover:bg-amber-400 group-hover:shadow-[0_0_8px_#FBBF24] transition-all" />
                                        <p className="text-xs text-white/90 leading-relaxed">{trend}</p>
                                    </div>
                                ))
                            ) : (
                                <div className="text-center py-4"><p className="text-xs text-white/40 italic">Insights generating...</p></div>
                            )}
                        </div>
                    </div>
                </div>
              </div>
            )}

            {/* AI Button */}
            <div className="relative z-10 pb-8">
              <NeuroPulseButton match={match} />
            </div>
          </div>
        )}

        {/* --- TAB: MANAGER --- */}
        {activeTab === 'manager' && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
             <div className="flex items-center gap-2 justify-center mb-3">
               {selectedLineup?.isConfirmed ? (
                 <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">Confirmed Lineups</span>
                 </div>
               ) : (
                 <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20">
                    <AlertCircle className="w-3 h-3 text-amber-400" />
                    <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">Possible Lineups</span>
                 </div>
               )}
             </div>

             <div className="flex justify-center items-center gap-4 px-8 mb-6">
                <button 
                   onClick={() => setSelectedTeamId(match.homeTeam.id)}
                   className={`flex-1 py-3 rounded-xl border transition-all duration-300 relative overflow-hidden group ${
                     selectedTeamId === match.homeTeam.id 
                       ? 'bg-indigo-600 border-indigo-400 shadow-[0_0_20px_rgba(99,102,241,0.4)] text-white' 
                       : 'bg-white/5 border-white/10 text-white/40 hover:bg-white/10 hover:border-white/20'
                   }`}
                >
                   {selectedTeamId === match.homeTeam.id && (
                      <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500 to-indigo-400 opacity-100 z-0" />
                   )}
                   <span className="relative z-10 text-xs font-bold uppercase tracking-wider">{match.homeTeam.name}</span>
                </button>

                <button 
                   onClick={() => setSelectedTeamId(match.awayTeam.id)}
                   className={`flex-1 py-3 rounded-xl border transition-all duration-300 relative overflow-hidden group ${
                     selectedTeamId === match.awayTeam.id 
                       ? 'bg-indigo-600 border-indigo-400 shadow-[0_0_20px_rgba(99,102,241,0.4)] text-white' 
                       : 'bg-white/5 border-white/10 text-white/40 hover:bg-white/10 hover:border-white/20'
                   }`}
                >
                   {selectedTeamId === match.awayTeam.id && (
                      <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500 to-indigo-400 opacity-100 z-0" />
                   )}
                   <span className="relative z-10 text-xs font-bold uppercase tracking-wider">{match.awayTeam.name}</span>
                </button>
             </div>

             {selectedLineup ? (
                <div className="animate-in zoom-in duration-500 mb-6">
                   <Pitch lineup={selectedLineup} isHome={selectedTeamId === match.homeTeam.id} />
                </div>
             ) : (
               <div className="h-64 flex items-center justify-center bg-white/5 rounded-xl border border-white/10 mx-4 mb-6">
                  <span className="text-white/30 text-xs uppercase tracking-wider">Lineup not available</span>
               </div>
             )}

             {selectedLineup && (
               <div className="space-y-4 animate-in slide-in-from-bottom-6 duration-700 delay-100">
                  <div className="bg-white/5 rounded-xl border border-white/5 p-3 flex items-center gap-4">
                     <div className="w-10 h-10 rounded-full border border-white/10 overflow-hidden bg-gray-800">
                        <img src={selectedLineup.manager.imageUrl} alt={selectedLineup.manager.name} className="w-full h-full object-cover" />
                     </div>
                     <div>
                        <span className="text-[10px] text-white/40 uppercase tracking-wider font-bold block">Head Coach</span>
                        <span className="text-sm text-white font-bold">{selectedLineup.manager.name}</span>
                     </div>
                  </div>
                  <SquadList title="Substitutes" items={selectedLineup.bench} />
                  <ElitePlayersSection homeLineup={match.homeTeam.lineup} awayLineup={match.awayTeam.lineup} />
               </div>
             )}
          </div>
        )}

        {/* --- TAB: STANDINGS --- */}
        {activeTab === 'standings' && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12 space-y-8">
             
             {/* 1. Standings Table */}
             <div className="overflow-hidden rounded-xl border border-white/10 bg-[#0A0E27]">
               <div className="bg-white/5 px-4 py-3 border-b border-white/5 flex justify-between items-center">
                 <span className="text-xs font-bold text-white uppercase tracking-wider">Live Standings</span>
                 <span className="text-[10px] text-emerald-400 animate-pulse font-mono">● LIVE UPDATE</span>
               </div>
               
               <div className="overflow-x-auto">
                 <table className="w-full text-left border-collapse">
                   <thead>
                     <tr className="text-[9px] uppercase text-white/40 font-bold border-b border-white/5">
                       <th className="p-3 pl-4">#</th>
                       <th className="p-3">Team</th>
                       <th className="p-3 text-center">P</th>
                       <th className="p-3 text-center hidden sm:table-cell">W</th>
                       <th className="p-3 text-center hidden sm:table-cell">D</th>
                       <th className="p-3 text-center hidden sm:table-cell">L</th>
                       <th className="p-3 text-center">+/-</th>
                       <th className="p-3 text-center">PTS</th>
                       <th className="p-3 text-center">Form</th>
                     </tr>
                   </thead>
                   <tbody className="text-xs font-medium divide-y divide-white/5">
                     {MOCK_STANDINGS.map((team) => (
                       <tr key={team.rank} className={`hover:bg-white/5 transition-colors ${team.teamName === match.homeTeam.name || team.teamName === match.awayTeam.name ? 'bg-white/5' : ''}`}>
                         <td className="p-3 pl-4">
                           <div className={`w-5 h-5 rounded flex items-center justify-center text-[10px] font-bold ${team.rank <= 4 ? 'bg-emerald-500/20 text-emerald-400' : team.rank >= 18 ? 'bg-rose-500/20 text-rose-400' : 'text-white/60'}`}>
                             {team.rank}
                           </div>
                         </td>
                         <td className="p-3">
                           <div className="flex items-center gap-2">
                             <img src={team.teamLogo} alt={team.teamName} className="w-5 h-5 object-contain" />
                             <span className={`truncate ${team.teamName === match.homeTeam.name || team.teamName === match.awayTeam.name ? 'text-white font-bold' : 'text-white/80'}`}>{team.teamName}</span>
                           </div>
                         </td>
                         <td className="p-3 text-center text-white/60">{team.played}</td>
                         <td className="p-3 text-center hidden sm:table-cell text-white/60">{team.won}</td>
                         <td className="p-3 text-center hidden sm:table-cell text-white/60">{team.drawn}</td>
                         <td className="p-3 text-center hidden sm:table-cell text-white/60">{team.lost}</td>
                         <td className="p-3 text-center text-white/60">
                            <span className={team.goalsFor - team.goalsAgainst > 0 ? 'text-emerald-400' : 'text-rose-400'}>
                              {team.goalsFor - team.goalsAgainst > 0 ? '+' : ''}{team.goalsFor - team.goalsAgainst}
                            </span>
                         </td>
                         <td className="p-3 text-center font-bold text-white">{team.points}</td>
                         <td className="p-3 text-center">
                           <div className="flex gap-0.5 justify-center">
                             {team.form.slice(0, 5).map((res, idx) => (
                               <div key={idx} className={`w-1.5 h-1.5 rounded-full ${res === 'W' ? 'bg-emerald-500' : res === 'D' ? 'bg-gray-500' : 'bg-rose-500'}`} />
                             ))}
                           </div>
                         </td>
                       </tr>
                     ))}
                   </tbody>
                 </table>
               </div>
             </div>

             {/* 2. Matches Section */}
             <div>
                <h3 className="text-xs font-bold text-white/40 uppercase tracking-widest mb-3 ml-1 flex items-center gap-2 animate-pulse">
                  <Layers className="w-3 h-3 text-indigo-400" /> <span className="text-indigo-400">Matches</span>
                </h3>

                <div className="bg-white/5 rounded-xl border border-white/5 overflow-hidden">
                   {/* Toggles */}
                   <div className="flex bg-black/20 p-1 border-b border-white/5">
                      <button 
                        onClick={() => setMatchesView('home')}
                        className={`flex-1 py-2 text-[9px] font-bold uppercase tracking-wider rounded-lg transition-all ${matchesView === 'home' ? 'bg-indigo-500 text-white shadow-lg' : 'text-white/40 hover:text-white/60'}`}
                      >
                        {match.homeTeam.name}
                      </button>
                      <button 
                        onClick={() => setMatchesView('h2h')}
                        className={`flex-1 py-2 text-[9px] font-bold uppercase tracking-wider rounded-lg transition-all ${matchesView === 'h2h' ? 'bg-white/20 text-white shadow-lg' : 'text-white/40 hover:text-white/60'}`}
                      >
                        H2H
                      </button>
                      <button 
                        onClick={() => setMatchesView('away')}
                        className={`flex-1 py-2 text-[9px] font-bold uppercase tracking-wider rounded-lg transition-all ${matchesView === 'away' ? 'bg-indigo-500 text-white shadow-lg' : 'text-white/40 hover:text-white/60'}`}
                      >
                        {match.awayTeam.name}
                      </button>
                   </div>

                   {/* Content List */}
                   <div className="max-h-[400px] overflow-y-auto">
                      {matchesView === 'h2h' && <MatchesHistory matches={MOCK_HISTORY} teamId="" />}
                      {matchesView === 'home' && (
                        <div className="p-8 text-center text-white/20 text-xs uppercase tracking-widest">
                           Last 10 {match.homeTeam.name} Matches
                        </div>
                      )}
                      {matchesView === 'away' && (
                        <div className="p-8 text-center text-white/20 text-xs uppercase tracking-widest">
                           Last 10 {match.awayTeam.name} Matches
                        </div>
                      )}
                   </div>
                </div>
             </div>

          </div>
        )}

      </div>
    </div>
  );
};