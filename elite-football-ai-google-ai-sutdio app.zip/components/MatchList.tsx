
import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Star, Calendar, Trophy } from 'lucide-react';
import { Match } from '../types';
import { LEAGUE_LOGOS } from '../constants';

interface MatchListProps {
  matches: Match[];
  onSelectMatch: (matchId: string) => void;
  onToggleFavorite: (matchId: string) => void;
  isFavoritesView?: boolean;
}

export const MatchList: React.FC<MatchListProps> = ({ matches, onSelectMatch, onToggleFavorite, isFavoritesView = false }) => {
  const [selectedDate, setSelectedDate] = useState<'yesterday' | 'today' | 'tomorrow'>('today');
  const [isLiveFilter, setIsLiveFilter] = useState(false);

  // --- Helper: Render League Groups ---
  const renderLeagueGroups = (matchSet: Match[]) => {
    const groupedByLeague = matchSet.reduce((acc, match) => {
      if (!acc[match.league]) {
        acc[match.league] = [];
      }
      acc[match.league].push(match);
      return acc;
    }, {} as Record<string, Match[]>);

    if (matchSet.length === 0) {
      return (
        <div className="text-center py-12 text-white/20">
           <Trophy className="w-8 h-8 mx-auto mb-2 opacity-50" />
          <p className="text-[10px] uppercase tracking-widest">No matches found</p>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {Object.entries(groupedByLeague).map(([league, leagueMatches]) => (
          <div key={league} className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden">
            
            {/* League Header */}
            <div className="bg-white/5 px-4 py-2 flex items-center gap-3 border-b border-white/5">
              {LEAGUE_LOGOS[league] ? (
                <img src={LEAGUE_LOGOS[league]} alt={league} className="w-5 h-5 object-contain" />
              ) : (
                <Trophy className="w-4 h-4 text-white/40" />
              )}
              <span className="text-xs font-bold text-white/80 uppercase tracking-wide">{league}</span>
            </div>

            {/* Matches in League */}
            <div className="divide-y divide-white/5">
              {leagueMatches.map((match) => (
                <div 
                  key={match.id} 
                  className="p-3 hover:bg-white/5 transition-colors flex items-center gap-4 active:bg-white/10 group cursor-pointer"
                  onClick={() => onSelectMatch(match.id)}
                >
                  
                  {/* Time / Status Column */}
                  <div className="w-10 flex flex-col items-center justify-center text-center flex-shrink-0">
                    {match.isLive ? (
                      <>
                        <span className="text-[10px] font-bold text-emerald-400 animate-pulse">{match.time}</span>
                        <div className="w-1 h-1 bg-emerald-500 rounded-full mt-1" />
                      </>
                    ) : (
                      <span className="text-[11px] font-mono text-white/40">{match.time}</span>
                    )}
                  </div>

                  {/* Divider */}
                  <div className="w-[1px] h-8 bg-white/5 flex-shrink-0" />

                  {/* Teams Column */}
                  <div className="flex-1 flex flex-col gap-2 text-left">
                    {/* Home Team */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <img src={match.homeTeam.logoUrl} alt={match.homeTeam.name} className="w-5 h-5 object-contain" />
                        <span className={`text-sm font-medium truncate ${match.isLive && match.homeTeam.score > match.awayTeam.score ? 'text-white' : 'text-white/70'}`}>
                          {match.homeTeam.name}
                        </span>
                      </div>
                      {match.isLive && <span className="text-sm font-bold font-mono text-white">{match.homeTeam.score}</span>}
                    </div>

                    {/* Away Team */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <img src={match.awayTeam.logoUrl} alt={match.awayTeam.name} className="w-5 h-5 object-contain" />
                        <span className={`text-sm font-medium truncate ${match.isLive && match.awayTeam.score > match.homeTeam.score ? 'text-white' : 'text-white/70'}`}>
                          {match.awayTeam.name}
                        </span>
                      </div>
                      {match.isLive && <span className="text-sm font-bold font-mono text-white">{match.awayTeam.score}</span>}
                    </div>
                  </div>

                  {/* Favorite Toggle */}
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleFavorite(match.id);
                    }}
                    className="p-2 -mr-2 text-white/20 hover:text-yellow-400 transition-colors active:scale-90"
                  >
                    <Star className={`w-5 h-5 ${match.isFavorite ? 'fill-yellow-400 text-yellow-400' : ''}`} />
                  </button>
                  
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  };

  // --- FAVORITES VIEW (Grouped by Date -> League) ---
  if (isFavoritesView) {
    // Group by Date first
    const matchesByDate = matches.reduce((acc, match) => {
      if (!acc[match.date]) {
        acc[match.date] = [];
      }
      acc[match.date].push(match);
      return acc;
    }, {} as Record<string, Match[]>);

    return (
      <div className="pb-24 pt-2 px-4 space-y-8">
        {Object.keys(matchesByDate).length === 0 ? (
           <div className="text-center py-20 text-white/20">
            <Star className="w-12 h-12 mx-auto mb-4 opacity-20" />
            <p className="text-sm font-tech uppercase tracking-widest">No Favorites Saved</p>
          </div>
        ) : (
          Object.entries(matchesByDate).map(([date, dateMatches]) => (
            <div key={date}>
              <h3 className="text-sm font-bold text-white mb-3 ml-1 border-l-2 border-indigo-500 pl-3">{date}</h3>
              {renderLeagueGroups(dateMatches as Match[])}
            </div>
          ))
        )}
      </div>
    );
  }

  // --- STANDARD VIEW (Date Filter -> League Groups) ---
  
  // Date Navigation Logic
  const handlePrevDate = () => {
    setIsLiveFilter(false);
    if (selectedDate === 'tomorrow') setSelectedDate('today');
    else if (selectedDate === 'today') setSelectedDate('yesterday');
  };

  const handleNextDate = () => {
    setIsLiveFilter(false);
    if (selectedDate === 'yesterday') setSelectedDate('today');
    else if (selectedDate === 'today') setSelectedDate('tomorrow');
  };

  const getDateLabel = () => {
    switch (selectedDate) {
      case 'yesterday': return 'Yesterday';
      case 'today': return 'Today';
      case 'tomorrow': return 'Tomorrow';
    }
  };

  const getDateValue = () => {
    switch (selectedDate) {
      case 'yesterday': return '23 OCT';
      case 'today': return '24 OCT';
      case 'tomorrow': return '25 OCT';
    }
  };

  const filteredMatches = matches.filter(m => {
    if (isLiveFilter) return m.isLive;
    
    if (selectedDate === 'today') return m.date.includes('Today');
    if (selectedDate === 'tomorrow') return m.date.includes('Tomorrow');
    // Fallback/Yesterday (mock data implies empty or specific handling)
    return false; 
  });

  return (
    <div className="pb-24">
      
      {/* Compact Date Navigation & Live Filter */}
      <div className="sticky top-[72px] z-30 bg-[#0A0E27]/95 backdrop-blur-md border-b border-white/5 py-2 mb-4">
        <div className="flex items-center justify-between px-4 gap-2">
          
          {/* Date Selector Bubble */}
          <div className={`flex items-center justify-between bg-white/5 border border-white/10 rounded-full p-1 flex-1 h-10 relative overflow-hidden transition-opacity duration-300 ${isLiveFilter ? 'opacity-40 grayscale' : 'opacity-100'}`}>
            <button 
               onClick={handlePrevDate}
               disabled={selectedDate === 'yesterday'}
               className={`w-8 h-full flex items-center justify-center rounded-full transition-colors ${selectedDate === 'yesterday' ? 'text-white/10 cursor-not-allowed' : 'text-white/40 hover:text-white hover:bg-white/5'}`}
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            
            <div className="flex flex-col items-center justify-center leading-none w-24">
              <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest mb-0.5 transition-all duration-300">
                {getDateLabel()}
              </span>
              <span className="text-xs font-tech text-white/90">
                {getDateValue()}
              </span>
            </div>

            <button 
               onClick={handleNextDate}
               disabled={selectedDate === 'tomorrow'}
               className={`w-8 h-full flex items-center justify-center rounded-full transition-colors ${selectedDate === 'tomorrow' ? 'text-white/10 cursor-not-allowed' : 'text-white/40 hover:text-white hover:bg-white/5'}`}
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* LIVE FILTER BUTTON */}
          <button 
            onClick={() => setIsLiveFilter(!isLiveFilter)}
            className={`
              h-10 px-3 rounded-full border flex items-center justify-center gap-2 transition-all duration-300 relative overflow-hidden whitespace-nowrap
              ${isLiveFilter 
                ? 'bg-rose-500/10 border-rose-500/50 text-rose-400 shadow-[0_0_15px_rgba(244,63,94,0.2)]' 
                : 'bg-white/5 border-white/10 text-white/40 hover:text-white hover:bg-white/10'
              }
            `}
          >
            <div className={`w-2 h-2 rounded-full ${isLiveFilter ? 'bg-rose-500 animate-pulse shadow-[0_0_8px_#F43F5E]' : 'bg-white/30'}`} />
            <span className="text-[10px] font-bold uppercase tracking-wider">Live</span>
          </button>

          {/* Calendar Toggle */}
          <button className="h-10 w-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/60 hover:text-white hover:bg-white/10 transition-colors relative flex-shrink-0">
            <Calendar className="w-5 h-5" />
            {/* Selection Bubble Indicator */}
            <div className="absolute top-2 right-2 w-2 h-2 bg-indigo-500 rounded-full ring-2 ring-[#0A0E27]" />
          </button>

        </div>
      </div>

      {/* Match List */}
      <div className="px-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
        {filteredMatches.length === 0 ? (
          <div className="text-center py-12 text-white/20">
            <Trophy className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-xs uppercase tracking-widest">
              {isLiveFilter ? 'No live matches now' : `No matches found for ${getDateLabel()}`}
            </p>
          </div>
        ) : (
          renderLeagueGroups(filteredMatches)
        )}
      </div>
    </div>
  );
};
