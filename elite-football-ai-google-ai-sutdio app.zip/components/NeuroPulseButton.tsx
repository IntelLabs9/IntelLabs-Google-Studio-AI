import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, BrainCircuit, Zap, Target, Activity, ShieldAlert, TrendingUp, ShieldCheck } from 'lucide-react';
import { AIPredictionStatus, Match, PredictionResult } from '../types';
import { generateMatchPrediction } from '../services/geminiService';

interface NeuroPulseButtonProps {
  match: Match;
}

// More advanced, professional steps
const ANALYSIS_STEPS = [
  { text: "Initializing Neural Network...", icon: Zap },
  { text: "Scanning Injury Reports & Squad Depth...", icon: ShieldAlert },
  { text: "Analyzing Tactical Formations...", icon: BrainCircuit },
  { text: "Simulating 10,000 Match Scenarios...", icon: Activity },
  { text: "Evaluating Real-Time Momentum...", icon: TrendingUp },
  { text: "Calculating Risk-Adjusted Alpha...", icon: Target },
  { text: "Finalizing Elite Strategy...", icon: Sparkles },
];

// --- CUSTOM AI LOGOS (Official Full Color SVGs) ---

const OpenAILogo = () => (
  <svg viewBox="0 0 24 24" className="w-full h-full">
    <path fill="#10A37F" d="M22.2819 9.8211a5.9847 5.9847 0 0 0-.5157-4.9108 6.0462 6.0462 0 0 0-6.5098-2.9A6.0651 6.0651 0 0 0 4.9807 4.1818a5.9847 5.9847 0 0 0-3.9977 2.9 6.0462 6.0462 0 0 0 .7427 7.0966 5.98 5.98 0 0 0 .511 4.9107 6.051 6.051 0 0 0 6.5146 2.9001A5.9847 5.9847 0 0 0 13.2599 24a6.0557 6.0557 0 0 0 5.7718-4.2058 5.9894 5.9894 0 0 0 3.9977-2.9001 6.0557 6.0557 0 0 0-.7475-7.0729zm-9.022 12.6081a4.4755 4.4755 0 0 1-2.8764-1.0408l.1419-.0804 4.7783-2.7582a.7948.7948 0 0 0 .3927-.6813v-6.7369l2.02 1.1686a.071.071 0 0 1 .038.052v5.5826a4.504 4.504 0 0 1-4.4945 4.4944zm-9.6607-4.1254a4.4708 4.4708 0 0 1-.5346-3.0137l.142.0852 4.783 2.7582a.7712.7712 0 0 0 .7806 0l5.8428-3.3685v2.3324a.0804.0804 0 0 1-.0332.0615L9.74 19.9502a4.4992 4.4992 0 0 1-6.1408-1.6464zM2.3408 7.8956a4.485 4.485 0 0 1 2.3655-1.9728V11.6a.7664.7664 0 0 0 .3879.6765l5.8144 3.3543-2.0201 1.1685a.0757.0757 0 0 1-.071 0l-4.8303-2.7865A4.504 4.504 0 0 1 2.3408 7.872zm16.5963 3.8558L13.1038 8.3829a.7712.7712 0 0 0-.7806 0l-5.8428 3.3685V9.419a.0804.0804 0 0 1 .0332-.0615l4.8539-2.8008a4.4992 4.4992 0 0 1 6.1408 1.6464 4.485 4.485 0 0 1 1.4288 3.5485zM19.3831 3.914a4.4755 4.4755 0 0 1 2.8764 1.0408l-.1419.0804-4.7783 2.7582a.7948.7948 0 0 0-.3927.6813v6.7369l-2.02-1.1686a.071.071 0 0 1-.038-.052V8.4086a4.504 4.504 0 0 1 4.4945-4.4944zm1.909 12.938a4.485 4.485 0 0 1-2.3655 1.9728V12.9006a.7664.7664 0 0 0-.3879-.6765L12.7243 8.8698l2.0201-1.1685a.0757.0757 0 0 1 .071 0l4.8303 2.7865a4.504 4.504 0 0 1 1.6464 6.3642z"/>
  </svg>
);

const ClaudeLogo = () => (
   <svg viewBox="0 0 24 24" className="w-full h-full">
      <path fill="#D97757" d="M17.42 8.22C17.42 8.22 17.42 8.22 17.42 8.22L17.42 8.22C17.42 8.22 17.42 8.22 17.42 8.22L16.06 5.5C16.06 5.5 16.06 5.5 16.06 5.5L16.06 5.5C16.06 5.5 16.06 5.5 16.06 5.5L12 0L7.94 5.5C7.94 5.5 7.94 5.5 7.94 5.5L7.94 5.5C7.94 5.5 7.94 5.5 7.94 5.5L6.58 8.22C6.58 8.22 6.58 8.22 6.58 8.22L6.58 8.22C6.58 8.22 6.58 8.22 6.58 8.22L0 12L6.58 15.78C6.58 15.78 6.58 15.78 6.58 15.78L6.58 15.78C6.58 15.78 6.58 15.78 6.58 15.78L7.94 18.5C7.94 18.5 7.94 18.5 7.94 18.5L7.94 18.5C7.94 18.5 7.94 18.5 7.94 18.5L12 24L16.06 18.5C16.06 18.5 16.06 18.5 16.06 18.5L16.06 18.5C16.06 18.5 16.06 18.5 16.06 18.5L17.42 15.78C17.42 15.78 17.42 15.78 17.42 15.78L17.42 15.78C17.42 15.78 17.42 15.78 17.42 15.78L24 12L17.42 8.22ZM12 16.5C9.51 16.5 7.5 14.49 7.5 12C7.5 9.51 9.51 7.5 12 7.5C14.49 7.5 16.5 9.51 16.5 12C16.5 14.49 14.49 16.5 12 16.5Z" />
   </svg>
);

const GeminiLogo = () => (
   <svg viewBox="0 0 24 24" className="w-full h-full">
      <defs>
        <linearGradient id="geminiGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style={{ stopColor: '#4E86F7', stopOpacity: 1 }} />
            <stop offset="100%" style={{ stopColor: '#D96570', stopOpacity: 1 }} />
        </linearGradient>
      </defs>
      <path fill="url(#geminiGradient)" d="M12 0L14.59 9.41L24 12L14.59 14.59L12 24L9.41 14.59L0 12L9.41 9.41L12 0Z" />
   </svg>
);

export const NeuroPulseButton: React.FC<NeuroPulseButtonProps> = ({ match }) => {
  const [status, setStatus] = useState<AIPredictionStatus>(AIPredictionStatus.IDLE);
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [analysisIndex, setAnalysisIndex] = useState(0);
  
  // Track timeouts to clear them if component unmounts
  const timeoutsRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  const triggerHaptic = (pattern: number | number[]) => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(pattern);
    }
  };

  // Cleanup timeouts on unmount
  useEffect(() => {
    return () => {
      timeoutsRef.current.forEach(clearTimeout);
    };
  }, []);

  const handlePredict = async () => {
    if (status !== AIPredictionStatus.IDLE) return;

    triggerHaptic(20);
    setStatus(AIPredictionStatus.CONNECTING);
    setAnalysisIndex(0);
    
    // Clear any existing timeouts
    timeoutsRef.current.forEach(clearTimeout);
    timeoutsRef.current = [];

    const apiPromise = generateMatchPrediction(match);

    // Total animation sequence configuration
    const STEP_DURATION = 900; // 0.9s per step
    const TOTAL_ANIMATION_TIME = ANALYSIS_STEPS.length * STEP_DURATION;

    // Schedule each step explicitly to run exactly once
    ANALYSIS_STEPS.forEach((_, index) => {
      const timeoutId = setTimeout(() => {
        setAnalysisIndex(index);
        triggerHaptic(15);
        
        // Update status text for visual variety during the process
        if (index === 2) setStatus(AIPredictionStatus.SYNTHESIZING);
        if (index === 5) setStatus(AIPredictionStatus.GENERATING);
        
      }, index * STEP_DURATION);
      
      timeoutsRef.current.push(timeoutId);
    });

    // Wait for both the API result and the minimum animation time
    const minTimePromise = new Promise(resolve => setTimeout(resolve, TOTAL_ANIMATION_TIME));
    
    try {
      const [result] = await Promise.all([apiPromise, minTimePromise]);
      setPrediction(result);
      setStatus(AIPredictionStatus.COMPLETED);
      triggerHaptic([50, 50, 100]); 
    } catch (e) {
      console.error("Prediction failed", e);
      setStatus(AIPredictionStatus.IDLE);
    }
  };

  // Calculate variables for the loading state
  const safeIndex = Math.min(analysisIndex, ANALYSIS_STEPS.length - 1);
  const CurrentIcon = ANALYSIS_STEPS[safeIndex].icon;
  const currentText = ANALYSIS_STEPS[safeIndex].text;

  return (
    <div className="w-full flex flex-col items-center mt-4 mb-2">
      
      {/* CONDITIONAL CONTENT: Either Button OR Result Card */}
      {status === AIPredictionStatus.COMPLETED && prediction ? (
        // --- RESULT CARD ---
        <div className="w-full mt-2 animate-in slide-in-from-bottom-4 fade-in duration-700">
          <div className="bg-[#0A0E27] border border-indigo-500/30 rounded-2xl p-5 shadow-[0_0_30px_rgba(99,102,241,0.1)] relative overflow-hidden group">
            
            {/* Background Glow */}
            <div className="absolute -right-10 -top-10 w-40 h-40 bg-indigo-500/10 rounded-full blur-3xl" />
            
            {/* Header */}
            <div className="flex items-center gap-2 mb-4">
               <Sparkles className="w-4 h-4 text-yellow-300" />
               <span className="text-xs font-bold text-white tracking-widest uppercase">Elite AI Predictions</span>
            </div>

            {/* Dual Predictions Grid */}
            <div className="grid grid-cols-2 gap-3 mb-5 relative z-10">
              
              {/* Conservative */}
              <div className="bg-emerald-500/5 border border-emerald-500/30 p-3 rounded-xl backdrop-blur-sm flex flex-col justify-between h-full">
                 <div className="flex items-center gap-1.5 mb-2">
                   <ShieldCheck className="w-3 h-3 text-emerald-400" />
                   <span className="text-[9px] text-emerald-400 font-bold uppercase tracking-wider">Conservative</span>
                 </div>
                 <div className="text-white font-bold text-sm leading-tight shadow-black drop-shadow-md">
                   {prediction.conservative}
                 </div>
              </div>

              {/* Aggressive */}
              <div className="bg-amber-500/5 border border-amber-500/30 p-3 rounded-xl backdrop-blur-sm flex flex-col justify-between h-full">
                 <div className="flex items-center gap-1.5 mb-2">
                   <Target className="w-3 h-3 text-amber-400" />
                   <span className="text-[9px] text-amber-400 font-bold uppercase tracking-wider">Aggressive</span>
                 </div>
                 <div className="text-white font-bold text-sm leading-tight shadow-black drop-shadow-md">
                   {prediction.aggressive}
                 </div>
              </div>

            </div>
            
            {/* Separator */}
            <div className="h-[1px] w-full bg-white/10 mb-4" />

            {/* Reasoning */}
            <div className="text-indigo-100/80 text-xs leading-relaxed space-y-2.5 relative z-10">
              {prediction.reasoning.split('\n').map((line, idx) => {
                const cleanLine = line.replace(/^[•-]\s*/, '');
                if (!cleanLine) return null;
                return (
                  <div key={idx} className="flex gap-2.5 items-start">
                    <div className="mt-1.5 min-w-[3px] h-[3px] rounded-full bg-indigo-400 shadow-[0_0_4px_#818CF8]" />
                    <span>{cleanLine}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        // --- BUTTON STATE (IDLE / LOADING) ---
        <>
          {/* Header Above Button - ENHANCED TYPOGRAPHY & ANIMATION */}
          <div className="relative group cursor-default mb-8 scale-110">
            <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-500 rounded-lg blur opacity-20 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
            <div className="relative text-sm sm:text-base font-tech font-bold uppercase tracking-[0.3em] text-transparent bg-clip-text bg-gradient-to-r from-indigo-200 via-white to-indigo-200 animate-shimmer drop-shadow-[0_0_8px_rgba(99,102,241,0.8)] group-hover:scale-105 transition-transform duration-300">
              ELITE AI FOOTBALL INTELLIGENCE
            </div>
          </div>

          <button
            onClick={handlePredict}
            disabled={status !== AIPredictionStatus.IDLE}
            className={`
              relative rounded-full transition-all duration-700 flex flex-col items-center justify-center group
              ${status === AIPredictionStatus.IDLE 
                ? 'w-36 h-36 hover:scale-105 hover:shadow-[0_0_50px_rgba(99,102,241,0.5)] cursor-pointer' 
                : 'w-44 h-44 cursor-default shadow-[0_0_60px_rgba(99,102,241,0.7)] scale-105'
              }
            `}
          >
            {/* ALIVE BACKGROUND ANIMATION */}
            <div className="absolute inset-0 rounded-full overflow-hidden">
               {/* The Spinning Conic Gradient */}
               <div className="absolute inset-[-50%] bg-[conic-gradient(from_0deg,transparent_0deg,#6366F1_60deg,transparent_120deg,#10B981_180deg,transparent_240deg,#F43F5E_300deg,transparent_360deg)] animate-[spin_4s_linear_infinite] opacity-70" />
               
               {/* Reverse Spin Layer */}
               <div className="absolute inset-[-50%] bg-[conic-gradient(from_180deg,transparent_0deg,rgba(255,255,255,0.1)_180deg,transparent_360deg)] animate-[spin_6s_linear_infinite_reverse] opacity-40" />

               {/* Inner Blur Mask */}
               <div className="absolute inset-[2px] bg-[#0A0E27]/90 rounded-full z-0 backdrop-blur-sm" />
               
               {/* Pulse Core */}
               <div className="absolute inset-0 bg-indigo-500/10 rounded-full animate-pulse-slow z-0" />
            </div>

            {/* BORDER RING */}
            <div className={`absolute inset-0 rounded-full border border-white/10 z-10 ${status !== AIPredictionStatus.IDLE ? 'border-indigo-400/60 shadow-[inset_0_0_20px_rgba(99,102,241,0.5)]' : ''}`} />

            {/* CONTENT LAYER */}
            <div className="relative z-20 flex flex-col items-center text-center px-2">
              
              {status === AIPredictionStatus.IDLE ? (
                <>
                  <BrainCircuit className="w-8 h-8 text-indigo-400 mb-1.5 group-hover:text-white transition-colors drop-shadow-[0_0_10px_rgba(99,102,241,0.8)]" />
                  <div className="flex flex-col leading-none gap-0.5">
                    <span className="text-[10px] text-indigo-300 font-tech tracking-[0.2em] uppercase">ELITE AI</span>
                    <span className="text-[11px] text-white font-bold font-tech tracking-[0.2em] uppercase group-hover:tracking-[0.25em] transition-all">PREDICTIONS</span>
                  </div>
                </>
              ) : (
                // LOADING STATE CONTENT
                <>
                  <CurrentIcon className="w-6 h-6 text-white mb-3 animate-bounce drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]" />
                  <span className="text-[9px] font-mono text-indigo-100 uppercase tracking-widest leading-tight animate-pulse px-1">
                    {currentText}
                  </span>
                </>
              )}
            </div>
          </button>
        </>
      )}

      {/* --- INFO SECTION (ALWAYS VISIBLE) --- */}
      <div className="mt-8 w-full px-1 animate-in fade-in slide-in-from-bottom-4 duration-1000">
          
          {/* Separator Header - ENHANCED TYPOGRAPHY & BADGE STYLE */}
          <div className="relative flex items-center justify-center mb-6 group">
            {/* Animated Line */}
            <div className="absolute h-[1px] w-full bg-gradient-to-r from-transparent via-indigo-400 to-transparent opacity-50 group-hover:opacity-100 group-hover:h-[2px] transition-all duration-500" />
            
            {/* Text Badge */}
            <span className="relative bg-[#0A0E27] px-5 py-2 rounded-full border border-indigo-500/20 text-[10px] sm:text-xs font-bold text-indigo-100 font-tech uppercase tracking-widest shadow-[0_0_15px_rgba(99,102,241,0.1)] group-hover:shadow-[0_0_25px_rgba(99,102,241,0.4)] group-hover:border-indigo-500/50 transition-all duration-300 whitespace-nowrap z-10">
              Experience the future of football predictions
            </span>
          </div>

          {/* Tech Specs Container */}
          <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/5 p-4 space-y-5 shadow-[0_0_30px_rgba(99,102,241,0.05)] relative overflow-hidden">
             {/* Ambient Flow Background */}
             <div className="absolute inset-0 bg-[conic-gradient(from_90deg,transparent_0deg,rgba(99,102,241,0.03)_180deg,transparent_360deg)] animate-[spin_10s_linear_infinite] opacity-50 pointer-events-none" />

             <div className="relative z-10 space-y-4">
                {/* Bullet 1 */}
                <div className="flex items-start gap-3 group">
                   <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-indigo-400 shadow-[0_0_8px_#818CF8] animate-pulse" />
                   <p className="text-xs text-indigo-100/90 leading-relaxed font-light">
                      Trained <span className="text-indigo-300 font-bold">Model Context Protocol</span> for advanced football reasoning.
                   </p>
                </div>

                {/* Bullet 2 (Icons) - UPDATED SIZE & LOGOS */}
                <div className="flex items-start gap-3 group">
                   <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-indigo-400 shadow-[0_0_8px_#818CF8] animate-pulse" />
                   <div className="flex flex-col gap-3 w-full">
                      <p className="text-xs text-indigo-100/90 leading-relaxed font-light">
                        Powered by the world's most advanced AI models:
                      </p>
                      <div className="flex items-center gap-4">
                         {/* ChatGPT */}
                         <div className="w-10 h-10 p-2 rounded-lg bg-white/10 border border-white/10 hover:bg-emerald-500/10 hover:border-emerald-500/30 transition-all duration-300 cursor-help flex items-center justify-center group/icon shadow-sm hover:shadow-[0_0_15px_rgba(16,185,129,0.2)]" title="ChatGPT">
                           <div className="w-6 h-6 group-hover/icon:scale-110 transition-transform duration-300">
                             <OpenAILogo />
                           </div>
                         </div>
                         
                         {/* Gemini */}
                         <div className="w-10 h-10 p-2 rounded-lg bg-white/10 border border-white/10 hover:bg-indigo-500/10 hover:border-indigo-500/30 transition-all duration-300 cursor-help flex items-center justify-center group/icon shadow-sm hover:shadow-[0_0_15px_rgba(99,102,241,0.2)]" title="Gemini">
                           <div className="w-6 h-6 group-hover/icon:scale-110 transition-transform duration-300">
                             <GeminiLogo />
                           </div>
                         </div>

                         {/* Claude */}
                         <div className="w-10 h-10 p-2 rounded-lg bg-white/10 border border-white/10 hover:bg-amber-500/10 hover:border-amber-500/30 transition-all duration-300 cursor-help flex items-center justify-center group/icon shadow-sm hover:shadow-[0_0_15px_rgba(251,191,36,0.2)]" title="Claude">
                           <div className="w-6 h-6 group-hover/icon:scale-110 transition-transform duration-300">
                             <ClaudeLogo />
                           </div>
                         </div>
                      </div>
                   </div>
                </div>

                {/* Bullet 3 */}
                <div className="flex items-start gap-3 group">
                   <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-indigo-400 shadow-[0_0_8px_#818CF8] animate-pulse" />
                   <p className="text-xs text-indigo-100/90 leading-relaxed font-light">
                      More than <span className="text-white font-bold">50 data points</span> analysis for high accuracy predictions.
                   </p>
                </div>
             </div>

             {/* Sub-Text Divider */}
             <div className="h-[1px] w-full bg-white/5 my-2" />

             {/* Sub-Text */}
             <div className="space-y-2 relative z-10">
                <p className="text-[10px] text-white/40 italic">
                   * Pre-Match Predictions ready 1 hour before kick off. (AI analyzes confirmed line-ups, injuries, and more...)
                </p>
                <p className="text-[10px] text-white/40 italic">
                   * Live-Match Predictions update and adjust according to live data in seconds.
                </p>
             </div>
          </div>
        </div>
    </div>
  );
};